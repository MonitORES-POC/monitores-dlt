#!/usr/bin/env bash

# The code from this file was called after Fablo generated Hyperledger Fabric configuration
echo "Executing post-generate hook"
